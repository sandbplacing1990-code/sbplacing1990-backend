import express from "express";
import http from "http";
import { Server } from "socket.io";
import cors from "cors";
import dotenv from "dotenv";
dotenv.config();

import products from "./routes/products.js";
import orders from "./routes/orders.js";
import upload from "./routes/upload.js";
import auth from "./routes/auth.js";

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: "*" } });

app.use(cors());
app.use(express.json());
app.use("/uploads", express.static("uploads"));

app.set('io', io);

app.use("/auth", auth);
app.use("/products", products);
app.use("/orders", orders);
app.use("/upload", upload);

app.get("/", (req, res) => res.send("Sbplacing1990-backend Running"));

io.on('connection', (socket) => {
  console.log('Socket connected', socket.id);
  socket.on('join_store', (data) => {
    if (data && data.store_id) {
      const room = `store_${data.store_id}`;
      socket.join(room);
      console.log('Socket', socket.id, 'joined', room);
    }
  });
  socket.on('disconnect', () => {
    console.log('Socket disconnected', socket.id);
  });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => console.log(`Server running on port ${PORT}`));
