import express from "express";
import db from "../db.js";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";
const router = express.Router();
const JWT_SECRET = process.env.JWT_SECRET || "replace_this_with_env_secret";

router.post('/register', async (req,res)=>{
  const { username, password, store_id, role } = req.body;
  if(!username || !password) return res.status(400).json({error:'username/password required'});
  const hash = await bcrypt.hash(password, 10);
  try{
    const result = await db.query('INSERT INTO users (username,password_hash,store_id,role) VALUES ($1,$2,$3,$4) RETURNING id', [username,hash,store_id,role||'vendor']);
    res.json({user_id: result.rows[0].id});
  }catch(err){
    res.status(500).json({error: err.message});
  }
});

router.post('/login', async (req,res)=>{
  const { username, password } = req.body;
  try{
    const result = await db.query('SELECT * FROM users WHERE username=$1', [username]);
    if(result.rowCount===0) return res.status(401).json({error:'invalid'});
    const row = result.rows[0];
    const match = await bcrypt.compare(password, row.password_hash);
    if(!match) return res.status(401).json({error:'invalid'});
    const token = jwt.sign({ user_id: row.id, store_id: row.store_id, role: row.role }, JWT_SECRET, { expiresIn: '30d' });
    res.json({ token, user: { id: row.id, username: row.username, store_id: row.store_id, role: row.role } });
  }catch(err){
    res.status(500).json({error:err.message});
  }
});

router.post('/token', async (req,res)=>{
  const { user_id, expo_push_token } = req.body;
  if(!user_id || !expo_push_token) return res.status(400).json({error:'user_id & token required'});
  try{
    await db.query('UPDATE users SET expo_push_token=$1 WHERE id=$2', [expo_push_token, user_id]);
    res.json({ok:true});
  }catch(err){
    res.status(500).json({error:err.message});
  }
});

export default router;
