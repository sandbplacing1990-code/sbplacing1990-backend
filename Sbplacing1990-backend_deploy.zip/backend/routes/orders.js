import express from "express";
import db from "../db.js";
import { Expo } from "expo-server-sdk";
const router = express.Router();

router.post("/", async (req,res)=>{
  const { customer, phone, address, items, total, store_id } = req.body;
  try{
    const r = await db.query('INSERT INTO orders (customer,phone,address,items,total,status,store_id) VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING id', [customer,phone,address,JSON.stringify(items),total,'pending',store_id]);
    const orderId = r.rows[0].id;
    const io = req.app.get('io');
    if(io && store_id){
      io.to(`store_${store_id}`).emit('orderCreated', { orderId, customer, total });
    }
    const vendors = await db.query("SELECT expo_push_token FROM users WHERE store_id=$1 AND role='vendor' AND expo_push_token IS NOT NULL", [store_id]);
    const expo = new Expo();
    const messages = [];
    for(const row of vendors.rows){
      if(Expo.isExpoPushToken(row.expo_push_token)) messages.push({ to: row.expo_push_token, sound: 'default', title: 'ออร์เดอร์ใหม่', body: `Order #${orderId} จาก ${customer} รวม ฿${total}` });
    }
    if(messages.length>0){
      const chunks = expo.chunkPushNotifications(messages);
      (async ()=>{
        for(const chunk of chunks){
          try{ await expo.sendPushNotificationsAsync(chunk); }catch(err){ console.error(err); }
        }
      })();
    }
    res.json({ order_id: orderId });
  }catch(err){ res.status(500).json({error:err.message}); }
});

router.get("/", async (req,res)=>{
 try{
   const r = await db.query('SELECT * FROM orders ORDER BY id DESC');
   res.json(r.rows);
 }catch(e){ res.status(500).json({error:e.message}); }
});

export default router;
