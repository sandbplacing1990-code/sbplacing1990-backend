import express from "express";
import db from "../db.js";
const router = express.Router();

router.get("/", async (req,res)=>{
 try{
   const r = await db.query('SELECT * FROM products ORDER BY id DESC');
   res.json(r.rows);
 }catch(e){ res.status(500).json({error:e.message}); }
});

router.post("/", async (req,res)=>{
 const {name,price,unit,stock,image,store_id}=req.body;
 try{
   const r = await db.query('INSERT INTO products (name,price,unit,stock,image,store_id) VALUES ($1,$2,$3,$4,$5,$6) RETURNING id', [name,price,unit,stock,image,store_id]);
   res.json({id:r.rows[0].id});
 }catch(err){ res.status(500).json({error:err.message}); }
});

export default router;
