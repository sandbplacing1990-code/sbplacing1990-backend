import db from '../db.js';

(async function(){
  try{
    await db.query(`CREATE TABLE IF NOT EXISTS users (
      id SERIAL PRIMARY KEY,
      username TEXT UNIQUE,
      password_hash TEXT,
      store_id INTEGER,
      role TEXT,
      expo_push_token TEXT
    )`);
    await db.query(`CREATE TABLE IF NOT EXISTS products (
      id SERIAL PRIMARY KEY,
      name TEXT,
      price NUMERIC,
      unit TEXT,
      stock NUMERIC,
      image TEXT,
      store_id INTEGER
    )`);
    await db.query(`CREATE TABLE IF NOT EXISTS orders (
      id SERIAL PRIMARY KEY,
      customer TEXT,
      phone TEXT,
      address TEXT,
      items TEXT,
      total NUMERIC,
      status TEXT,
      store_id INTEGER
    )`);
    console.log('Migrations completed');
    process.exit(0);
  }catch(err){
    console.error(err);
    process.exit(1);
  }
})();
