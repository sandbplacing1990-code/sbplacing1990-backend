Sbplacing1990-backend - Deploy package (Postgres-ready)

1) Upload this 'backend' folder as a ZIP to Render (Deploy > Web Service > Deploy from ZIP).
2) Create a Postgres database on Render and copy DATABASE_URL.
3) In Render service settings set Environment Variables:
   - DATABASE_URL
   - JWT_SECRET (a long secret)
   - NODE_ENV=production
4) Deploy. After build, open Shell and run:
   npm install
   node migrations/init_db.js
5) Create initial vendor:
   curl -X POST https://<YOUR_BACKEND_URL>/auth/register -H "Content-Type: application/json" -d '{"username":"vendor","password":"vendorpass","store_id":1,"role":"vendor"}'
6) Login:
   curl -X POST https://<YOUR_BACKEND_URL>/auth/login -H "Content-Type: application/json" -d '{"username":"vendor","password":"vendorpass"}'
7) Update your mobile app BASE_URL to https://<YOUR_BACKEND_URL>

Notes:
- For file uploads use S3 in production.
- Keep JWT_SECRET secure.
